<div class="ytvi-wrap vi-demo-col-content">
    <div class="ytvi-login-success">
        <?php include_once(EPYTVI_INCLUDES_PATH . 'vi_login_success_content.php'); ?>
    </div>
</div>
